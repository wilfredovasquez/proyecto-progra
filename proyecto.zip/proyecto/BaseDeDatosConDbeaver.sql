create table registrar_do (

id_doctores int not null,
nombre varchar (50),
especialidad varchar(50),
direccion varchar(50),
edad integer,
centro_hospitalario varchar(50),
 colegiado varchar(50),
fecha_de_registro date,

primary key (id_doctores)
);