package com.proyecto_progra.hospital_la_bendicion.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto_progra.hospital_la_bendicion.entidades.Registro_Doctor;
import com.proyecto_progra.hospital_la_bendicion.repositorio.registro_doctor_repositorio;

@Service


public class registrar_doctor_sevicio {

    @Autowired
private registro_doctor_repositorio registrodoctor_repositorio;

public List<Registro_Doctor> consultarRegistro_Dotor(){
    return (List<Registro_Doctor>) registrodoctor_repositorio.findAll();
}
/**
 * @param registro_doctor
 * @return el registro de registrar doctor
 */
@SuppressWarnings("null")
public Registro_Doctor regist_doctor(Registro_Doctor registro_doctor){
    return registro_doctor.Save(registro_doctor);
    

}


}
