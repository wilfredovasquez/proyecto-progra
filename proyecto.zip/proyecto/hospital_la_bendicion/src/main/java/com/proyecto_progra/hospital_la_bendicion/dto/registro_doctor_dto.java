package com.proyecto_progra.hospital_la_bendicion.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class registro_doctor_dto {


private String nombre;
private String especialidad;
private String direccion;
private Integer edad;
private String centro_hospitalario;
private String colegiado;
private String fecha_de_registro;
 


}
