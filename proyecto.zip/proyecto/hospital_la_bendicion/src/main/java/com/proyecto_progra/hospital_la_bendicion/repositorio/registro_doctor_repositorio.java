package com.proyecto_progra.hospital_la_bendicion.repositorio;


import org.springframework.data.repository.CrudRepository;

import com.proyecto_progra.hospital_la_bendicion.entidades.Registro_Doctor;


public interface registro_doctor_repositorio extends CrudRepository < Registro_Doctor,Long>  {

}
