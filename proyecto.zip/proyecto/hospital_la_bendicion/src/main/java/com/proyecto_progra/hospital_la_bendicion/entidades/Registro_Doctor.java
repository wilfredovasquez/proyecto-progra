package com.proyecto_progra.hospital_la_bendicion.entidades;

import java.sql.Date;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;





@Entity
@Table(name = "registrar_do")
@Data 

@NoArgsConstructor
@AllArgsConstructor



public class Registro_Doctor {

@Id
@Column(name="id_doctores")
@GeneratedValue(strategy= GenerationType.IDENTITY)
private Long IdDoctor;
@Column(name= "nombre") 

private String Colegiado;
private String NombreDoctor;
private String Especialidad;
private String Direccion;
private String Centro_Hospitalario;
private Integer Edad;
private Date Fecha_De_Registro;
public Registro_Doctor Save(Registro_Doctor registro_doctor) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'Save'");
}




}
