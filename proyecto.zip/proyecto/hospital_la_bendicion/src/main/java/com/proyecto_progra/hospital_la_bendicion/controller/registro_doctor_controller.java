package com.proyecto_progra.hospital_la_bendicion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto_progra.hospital_la_bendicion.dto.registro_doctor_dto;
import com.proyecto_progra.hospital_la_bendicion.entidades.Registro_Doctor;
import com.proyecto_progra.hospital_la_bendicion.services.registrar_doctor_sevicio;






@RestController
@RequestMapping("/api")
public class registro_doctor_controller {

    @Autowired
private registrar_doctor_sevicio servicioregistrar;

@GetMapping("/listarRegistro_doctor")


public List<Registro_Doctor > consultaRegistro_Doctor(){
   return servicioregistrar. consultaRegistro_Doctor();
}
    

/**
 * @param registrar_doctoresjson
 * @return
 */
@GetMapping("registrardoc")

public Registro_Doctor registraRegistro_Doctor(@RequestMapping registro_doctor_dto registrar_doctoresjson ) {

Registro_Doctor registrardoctores= new registrardoctores();

registrardoctores.setDireccion(registrar_doctoresjson.getDireccion());
registrardoctores.setEdad(registrar_doctoresjson.getEdad());
registrardoctores.setNombreDoctor(registrar_doctoresjson.getCentro_hospitalario());
registrardoctores.setCentro_Hospitalario(registrar_doctoresjson.getCentro_hospitalario());
registrardoctores.setColegiado(registrar_doctoresjson.getColegiado());
registrardoctores.setEspecialidad(registrar_doctoresjson.getEspecialidad());

 return servicioregistrar.regist_doctor(registrardoctores);



}



}
















}


