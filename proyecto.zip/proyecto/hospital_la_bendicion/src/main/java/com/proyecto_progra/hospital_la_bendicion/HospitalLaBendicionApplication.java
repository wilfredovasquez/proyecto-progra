package com.proyecto_progra.hospital_la_bendicion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalLaBendicionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalLaBendicionApplication.class, args);
	}

}
